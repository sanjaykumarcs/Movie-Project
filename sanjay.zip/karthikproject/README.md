# movie-ticket-booking-with-php-and-mysql
This is a mini project which i have done during 5th sem
This project uses HTML,CSS,JS, Bootstrap for front end
Php and MySQL as backend I have used Apache server as 
Host server through xampp and coded in vs code 
It also has reports which extracts data from database
And is user friendly
